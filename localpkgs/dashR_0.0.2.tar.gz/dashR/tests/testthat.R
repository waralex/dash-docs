library(testthat)
library(dashR)

test_check("dashR")
