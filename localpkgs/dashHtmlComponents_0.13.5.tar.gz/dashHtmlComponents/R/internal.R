.dashHtmlComponents_js_metadata <- function() {
deps_metadata <- list(`dash_html_components` = structure(list(name = "dash_html_components",
version = "0.13.5", src = list(href = NULL,
file = "deps/"), meta = NULL,
script = "dash_html_components.min.js",
stylesheet = NULL, head = NULL, attachment = NULL, package = "dashHtmlComponents",
all_files = FALSE), class = "html_dependency"))
return(deps_metadata)
}