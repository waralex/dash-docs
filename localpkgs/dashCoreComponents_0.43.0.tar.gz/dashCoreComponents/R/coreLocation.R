# AUTO GENERATED FILE - DO NOT EDIT

coreLocation <- function(id=NULL, pathname=NULL, search=NULL, hash=NULL, href=NULL, refresh=NULL) {
    
    component <- list(
        props = list(id=id, pathname=pathname, search=search, hash=hash, href=href, refresh=refresh),
        type = 'Location',
        namespace = 'dash_core_components',
        propNames = c('id', 'pathname', 'search', 'hash', 'href', 'refresh'),
        package = 'dashCoreComponents'
        )

    component$props <- filter_null(component$props)

    structure(component, class = c('dash_component', 'list'))
}