# AUTO GENERATED FILE - DO NOT EDIT

coreTab <- function(children=NULL, id=NULL, label=NULL, value=NULL, disabled=NULL, disabled_style=NULL, disabled_className=NULL, className=NULL, selected_className=NULL, style=NULL, selected_style=NULL) {
    
    component <- list(
        props = list(children=children, id=id, label=label, value=value, disabled=disabled, disabled_style=disabled_style, disabled_className=disabled_className, className=className, selected_className=selected_className, style=style, selected_style=selected_style),
        type = 'Tab',
        namespace = 'dash_core_components',
        propNames = c('children', 'id', 'label', 'value', 'disabled', 'disabled_style', 'disabled_className', 'className', 'selected_className', 'style', 'selected_style'),
        package = 'dashCoreComponents'
        )

    component$props <- filter_null(component$props)

    structure(component, class = c('dash_component', 'list'))
}