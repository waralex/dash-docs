.dashCoreComponents_js_metadata <- function() {
deps_metadata <- list(`dash_core_components_0` = structure(list(name = "dash_core_components_0",
version = "0", src = list(href = NULL,
file = "deps/"), meta = NULL,
script = "plotly-1.44.1.min.js",
stylesheet = NULL, head = NULL, attachment = NULL, package = "dashCoreComponents",
all_files = FALSE), class = "html_dependency"),
`dash_core_components` = structure(list(name = "dash_core_components",
version = "0", src = list(href = NULL,
file = "deps/"), meta = NULL,
script = "dash_core_components.min.js",
stylesheet = NULL, head = NULL, attachment = NULL, package = "dashCoreComponents",
all_files = FALSE), class = "html_dependency"),
`dash_core_components` = structure(list(name = "dash_core_components",
version = "0", src = list(href = NULL,
file = "deps/"), meta = NULL,
script = "dash_core_components.min.js.map",
stylesheet = NULL, head = NULL, attachment = NULL, package = "dashCoreComponents",
all_files = FALSE), class = "html_dependency"))
return(deps_metadata)
}