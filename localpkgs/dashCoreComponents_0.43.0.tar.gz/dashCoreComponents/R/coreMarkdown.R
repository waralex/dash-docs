# AUTO GENERATED FILE - DO NOT EDIT

coreMarkdown <- function(children=NULL, id=NULL, className=NULL, containerProps=NULL, dangerously_allow_html=NULL) {
    
    component <- list(
        props = list(children=children, id=id, className=className, containerProps=containerProps, dangerously_allow_html=dangerously_allow_html),
        type = 'Markdown',
        namespace = 'dash_core_components',
        propNames = c('children', 'id', 'className', 'containerProps', 'dangerously_allow_html'),
        package = 'dashCoreComponents'
        )

    component$props <- filter_null(component$props)

    structure(component, class = c('dash_component', 'list'))
}