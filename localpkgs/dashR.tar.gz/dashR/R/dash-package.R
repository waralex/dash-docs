#' An implementation of the dash protocol for authoring reactive web applications
#'
#' Coming soon
#'
'_PACKAGE'
